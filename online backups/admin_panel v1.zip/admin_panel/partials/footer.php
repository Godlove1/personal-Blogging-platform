</main>
</div>
<!-- footer -->
<footer class="static bottom-0 text-xs bg-gray-200 p-2 mt-4">
<p class="text-center text-gray-500">&copy; 2023 All rights Reserved, massi martha.</p>
</footer>

<script>
    document.getElementById('go-back').addEventListener('click', () => {
  history.back();
});
</script>
<script src="../js/admin-menu.js"></script>
<script src="../js/imgpreview.js"></script>
</body>
</html>