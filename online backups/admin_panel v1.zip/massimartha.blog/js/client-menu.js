

const menuBtn=document.querySelector('.fa-bars');
const menuClose=document.querySelector('.fa-close');
// const navbar=document.querySelector('.mobile__sidebar');
const mobicontainer=document.querySelector('#mobiside');

const openNav=()=>{
mobicontainer.style.width='100%';
}


const closeNav=()=>{
    mobicontainer.style.width='0';
    }